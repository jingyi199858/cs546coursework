const albumData = require("./albums");
const bandData = require("./bands");

module.exports = {
  bands: bandData,
  albums: albumData
};
