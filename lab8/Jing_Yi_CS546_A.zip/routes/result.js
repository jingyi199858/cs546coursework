const express = require("express");
const router = express.Router();
const data = require("../data");
const checker = data.palindrome;

router.post("/",async (req, res) => {
	if (req.body['text-to-test']) {
        const result = checker.palindrome(req.body['text-to-test']);
		if(result == true){
            res.render("result", {title: "Result!", text: req.body['text-to-test'], result: result, class: "success"});
        }
		else{
            res.render("result", {title: "Result!", text: req.body['text-to-test'], result: result, class: "failure"});
        }
	} else {
		res.status(400).render("error", {title: "Error", description: "No text entered", class: "error"});
	}
});

router.get("/", async(req, res) => {
	res.status(400).render("error", {title: "Error"});
});

module.exports = router;